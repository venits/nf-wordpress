<?php
    /**
     * Plugin Name: NativeForms
     * Author: NativeForms
     * Author URI: https://nativeforms.com/
     * Plugin URI: https://nativeforms.com/wordpress
     * Description: Build forms, surveys & polls for WordPress. Add forms to your website in few minutes and start getting more from your visitors.
     * Version: 1.0
     * Requires at least: 4.7
     * Requires PHP: 5.2.4
     * License: GPLv2 or later
     * License URI: https://www.gnu.org/licenses/gpl-2.0.html
     * Text Domain:: nativeforms
     */

    namespace Dodel\Nativeforms;

    final class Nativeforms{
        public function __construct(){
           add_action( 'admin_menu', [$this, 'plugin_menu'] );
           add_action('enqueue_block_editor_assets', [$this, 'load_block']);
           add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
           add_action('wp_footer', [$this, 'wp_footer']);
           add_action('admin_enqueue_scripts', [$this, 'enqueue_admin']);
           add_action( 'after_setup_theme', [$this,'theme_setup'] );
           add_action ('admin_footer', [$this, 'admin_footer']);
           add_shortcode( 'native-forms', [$this, 'create_nativeforms_shortcode'] );
        }

        // Shortcode: [native-forms id=""]
        public function create_nativeforms_shortcode($atts) {

            $atts = shortcode_atts(
                array(
                    'id' => '',
                ),
                $atts,
                'native-forms'
            );

            $id = $atts['id'];
            ob_start();
            ?>
                <iframe src="https://form.nativeforms.com/<?php echo esc_attr($id);?>" width="100%" height="600" frameborder="0" class="nf-resizable-form" > </iframe>
            <?php
            return ob_get_clean();
        }

        public function admin_footer(){
            ?>
            <div style="display:none">
            </div>
                <style>
                    #TB_ajaxContent{
                        width: unset !important;
                    }
                </style>
            <?php
        }

        public function register_buttons( $buttons ) {
            array_push( $buttons, 'nativeformsbtn' );
            return $buttons;
        }

        public function add_buttons( $plugin_array ) {
            $plugin_array['nativeformsbtn'] = plugin_dir_url(__FILE__).'/classic.js';
            return $plugin_array;
        }

        public function toolbar_buttons(){
            add_filter( 'mce_external_plugins', [$this, 'add_buttons'] );
            add_filter( 'mce_buttons', [$this, 'register_buttons'] );
        }

        public function theme_setup(){
            add_action( 'init', [$this, 'toolbar_buttons'] );
        }

        public function wp_footer(){
            ?>
                <style>
                    .wp-block-dodel-nativeforms-block div.block-of-form{
                        display: none;
                    }
                    .wp-block-dodel-nativeforms-block div{
                        padding: 0 !important;
                        background-color: transparent !important;
                        border: 0 !important;
                        text-align: unset !important;
                    }
                </style>
            <?php
        }

        public function enqueue_admin(){
            wp_enqueue_script( 'nativeforms-plugin-script', plugin_dir_url(__FILE__).'/admin.js');
            wp_enqueue_script( 'nativeforms-script', 'https://script.nativeforms.com/main.js');
        }

        public function enqueue_scripts(){
            wp_enqueue_script( 'nativeforms-script', 'https://script.nativeforms.com/main.js');
        }

        public function plugin_menu() {
            add_menu_page( 'NativeForms', 'NativeForms', 'manage_options', 'native-forms', [$this, 'plugin_options'], 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAMAAAC6V+0/AAAAvVBMVEUiAP8uDv8yE/88Hv9VPP9dRP9hSP9jS/9mTf9oUP9oUf9rVP9uWf9zXf90X/96Zv+Abf+Cb/+Ecf+Hdf+KeP+Lef+Mev+OfP+Pf/+Qf/+Tgv+XiP+YiP+aiv+bi/+cjf+gkv+om/+toP+uof+vo/+5rv+6r/+6sP/Du//Hv//PyP/Vzv/Y0v/f2//h3f/i3f/j3//m4v/r6P/s6v/x7//y8f/18//29P/39v/49//5+P/7+//9/P/9/f////8DSW7hAAAAq0lEQVR42oSNA5rDABSEZ23UbmPbfPe/1Rpx/s9DmPdo8GxjjiYf0iiXW0Gd1KXbiIIgUOv7pJ4DgVDVJiRsHaDY/iksNykO8HfmK13+SI8ehYEIqMGLkuKH8yDZAJvJh0wi/mCyyYZWH1r1e4IN8WCL14qWWU90nCCYVLSTe4cJaG9wqDClG+1KT2K2pu3l7AJlfoYKCyzfxwQyBn9wCWMKSTCosaGLcdsCAOO4ENmdll4oAAAAAElFTkSuQmCC' );
        }
        
        public function plugin_options() {
            if ( !current_user_can( 'manage_options' ) )  {
                wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
            }
            ?>
                <div class="wrap">
                    <iframe style="width: 100%;" id="wp-iframe" src="https://app.nativeforms.com"></iframe>
                </div>
                <script>
                    window.addEventListener('load', ()=>{
                        document.querySelector('#wp-iframe').style.height = (document.querySelector('#wpwrap').offsetHeight - document.querySelector('#wpfooter').offsetHeight - document.querySelector('#wpbody-content .wrap').offsetTop - 65) + 'px'
                    })
                </script>
            <?php
        }

        public function load_block(){
            wp_enqueue_script(
                'nativeforms-block',
                plugin_dir_url(__FILE__) . 'nativeforms-block.js',
                array('wp-blocks','wp-editor'),
                true
              );
        }
    }

    new Nativeforms;